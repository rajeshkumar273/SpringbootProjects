package com.example.dto;

import lombok.Data;

@Data
public class CandidateDto {
	
	private String userName;
	private String password;

}
