package com.example.service;



import com.example.dto.CustomerDetailsDto;


public interface CustomerService {
	
	String customerRegistration(CustomerDetailsDto customerDetailsDto);

}