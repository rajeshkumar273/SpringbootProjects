package com.mrk.ricestore.controller;



import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.util.UriComponentsBuilder;

import com.mrk.ricestore.dto.PhoneDetails;
import com.mrk.ricestore.dto.UserDetails;


@RestController
public class UsersController {
	
	
	
	@RequestMapping("/add")
	public String addUser(@RequestBody UserDetails userDetails) {
		
		//Calling Rest Service of another application.
		
		
		//URL: http://localhost:9999/flipkart/user/create
		
		//Method : POST
		
		// Request Payload: Yes
		
		/*
		{
			  "name": "string",
			  "email": "string",
			  "password": "string",
			  "contact": 0,
			  "city": "string",
			  "gender": "string"
			}
		
		*/
		
		//Create a Java class associated to request payload

		
		//Response : String 
		
		/*
		
		UserDetails userDetails = new UserDetails();
		userDetails.setName("Tim Cook");
		userDetails.setEmail("timcook@gmail.com");
		userDetails.setPassword("Rajesh@123");
		userDetails.setContact(834956863);
		userDetails.setCity("BLR");
		userDetails.setGender("Male");
		
		*/
		
		
		//RequestBody
		
		HttpEntity<UserDetails> httpEntity = new HttpEntity<UserDetails>(userDetails);
		
		
		
		RestTemplate restTemplate=new RestTemplate();
		ResponseEntity<String> responseEntity=	restTemplate.exchange("http://localhost:9999/flipkart/user/create",
											 HttpMethod.POST, httpEntity, String.class);
		
		//restTemplate.postForEntity("http://localhost:9999/flipkart/user/create", responseEntity, String.class); 
	
	
		String response= responseEntity.getBody();
		
		System.out.println("Response :"+response);
		System.out.println("Status Code:" +responseEntity.getStatusCode());
		System.out.println();
		return response;
	}

	
	
	//Calling another Service with Query params
	
	@RequestMapping("/get/users")
	public List<UserDetails> getUsersInfomation() {
		
		// URL: http://localhost:9999/flipkart/users/info?city=Guntur&gender=Male
		//Method: Get
		
		
		//UriComponentsBuilder.fromUriString(getUsersInfomation()) dynamically calling url
		
		String url="http://localhost:9999/flipkart/users/info?city={cityName}&gender={genderName}";
		
		//ToDO: pass values dynamically here,
		Map<String, String> values= new HashMap<>();
		values.put("cityName", "Hyd");
		values.put("genderName", "Male");
		
		RestTemplate restTemplate= new RestTemplate();
		//restTemplate.exchange(getUsersInfomation(), HttpMethod.GET, null, null, null)
		List<UserDetails> users=	restTemplate.getForEntity(url, List.class, values).getBody();
		
		System.out.println(users);
		
		return users;
	}
	
	@RequestMapping("/get/phonedetails")
	public List<PhoneDetails> getPhoneDetails() {
		
		String url ="https://api.restful-api.dev/objects";
		
		RestTemplate restTemplate = new RestTemplate();
		List<PhoneDetails> phones=restTemplate.getForEntity(url, List.class).getBody();
		
		System.out.println(phones);
		
		return phones;
		
		
	}
	
}
