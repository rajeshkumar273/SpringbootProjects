package com.mrk.ricestore.dto;

public class PhoneDetails {
	
	private int id;
	private String name;
	PhoneDesc data;

}
